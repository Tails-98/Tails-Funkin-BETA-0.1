Tails Funkin Psych mod - custom_notetypes folder.
