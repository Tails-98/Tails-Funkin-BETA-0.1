Tails Funkin Psych mod - custom_events folder.
