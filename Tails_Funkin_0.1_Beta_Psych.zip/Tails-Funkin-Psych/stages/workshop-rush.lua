function onCreate()
    makeLuaSprite('workshopBack', 'stages/workshop-rush/Workshop-rush', 0, 0)
    
    -- Larger background to reduce black bars
    setGraphicSize('workshopBack', 1920, 1080)
    setScrollFactor('workshopBack', 0.9, 0.9)
    
    screenCenter('workshopBack', 'xy')
    setProperty('workshopBack.y', getProperty('workshopBack.y') - 60)
    
    addLuaSprite('workshopBack', false)

    -- Character positions
    setProperty('boyfriend.x', 870)
    setProperty('boyfriend.y', 600)
    setProperty('dad.x', 200)
    setProperty('dad.y', 600)
    setProperty('gf.x', 480)
    setProperty('gf.y', 540)
end
