Tails Funkin' 0.1 Beta — Psych Engine 1.0.4
============================================

Song: Workshop Rush
Week: Tails Workshop
Opponent: Tails
Player: Boyfriend
GF: Sonic

Requirements
------------
Psych Engine 1.0.4 (PC or a mobile build that loads a mods folder).

Install
-------
1. Extract the archive.
2. Put the Tails-Funkin-Psych folder into the mods folder next to Psych Engine.
   Example: PsychEngine/mods/Tails-Funkin-Psych/
3. Launch the game. If the week does not show up, enable the mod in the Mods menu.
4. The song is in Story Mode (Tails Workshop) and Freeplay (Workshop Rush).

Difficulty
----------
The week lists Hard. Charts exist for both normal
(workshop-rush.json) and Hard (workshop-rush-hard.json).

Contents
--------
- characters/     — Tails and Sonic
- data/workshop-rush/ — chart and song script
- songs/workshop-rush/ — Inst.ogg, Voices-Player.ogg (BF), Voices-Opponent.ogg (Tails)
- stages/         — Workshop Rush stage
- weeks/          — Tails Workshop week
- images/         — sprites, icon, background

Notes
-----
- The Tails sprite is the original atlas, with no added pupils.
- Boyfriend's voice was replaced with the supplied stem.
- Tails' voice is the original mod stem.
- The chart was built from the vocal stems. Early sections are assigned to Tails so he starts.
- The background is scaled up to reduce black bars.

Known limits
------------
- Tails can look eyeless: the source atlas has no pupils.
- The chart is automatic. Arrow directions were not hand-tuned note by note.
- Tails' voice has not been replaced with a new performance.

Credits
-------
Sonic / Tails characters — SEGA.
Psych Engine — Shadow Mario and contributors.
This build's conversion and edits are for personal use.
