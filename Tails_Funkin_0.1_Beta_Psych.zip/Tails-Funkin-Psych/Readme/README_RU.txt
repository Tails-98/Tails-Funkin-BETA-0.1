Tails Funkin' 0.1 Beta — Psych Engine 1.0.4
============================================

Песня: Workshop Rush
Неделя: Tails Workshop
Оппонент: Tails
Игрок: Boyfriend
GF: Sonic

Требования
----------
Psych Engine 1.0.4 (ПК или мобильная сборка, совместимая с папкой mods).

Установка
---------
1. Распакуй архив.
2. Папку Tails-Funkin-Psych положи в папку mods рядом с Psych Engine.
   Пример: PsychEngine/mods/Tails-Funkin-Psych/
3. Запусти игру. Если неделя не появилась — включи мод в меню Mods.
4. Песня в Story Mode (Tails Workshop) и в Freeplay (Workshop Rush).

Сложность
---------
В неделе указан Hard. Файл чарта есть и для обычной сложности
(workshop-rush.json), и для Hard (workshop-rush-hard.json).

Что внутри
----------
- characters/     — Tails и Sonic
- data/workshop-rush/ — чарт и скрипт песни
- songs/workshop-rush/ — Inst.ogg, Voices-Player.ogg (BF), Voices-Opponent.ogg (Tails)
- stages/         — сцена Workshop Rush
- weeks/          — неделя Tails Workshop
- images/         — спрайты, иконка, фон

Заметки
-------
- Спрайт Tails — оригинальный, без дорисованных зрачков.
- Голос Boyfriend заменён на присланную дорожку.
- Голос Tails — оригинальный из мода.
- Чарт собран по голосовым дорожкам. Первые секции отданы Tails, чтобы он начинал.
- Фон увеличен, чтобы меньше чёрных полос по краям.

Известные ограничения
---------------------
- Спрайт Tails может выглядеть пустым в глазах: зрачки в исходном атласе отсутствуют.
- Чарт автоматический. Направление стрелок не выверено вручную под каждую ноту.
- Голос Tails не заменён на новый актёрский вокал.

Кредиты
-------
Персонажи Sonic / Tails — SEGA.
Psych Engine — Shadow Mario и сообщество.
Конвертация и правки этой сборки — для личного использования.
