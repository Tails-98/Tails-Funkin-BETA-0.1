Tails Funkin' 0.1 Beta — Psych Engine 1.0.4
============================================

README_RU.txt — русская версия
README_EN.txt — English version

------------------------------------------------------------
РУССКИЙ
------------------------------------------------------------

Песня: Workshop Rush
Неделя: Tails Workshop
Оппонент: Tails
Игрок: Boyfriend
GF: Sonic

Требования
Psych Engine 1.0.4 (ПК или мобильная сборка с папкой mods).

Установка
1. Распакуй архив.
2. Папку Tails-Funkin-Psych положи в mods рядом с Psych Engine.
   Пример: PsychEngine/mods/Tails-Funkin-Psych/
3. Запусти игру. Если неделя не появилась — включи мод в меню Mods.
4. Песня в Story Mode (Tails Workshop) и в Freeplay (Workshop Rush).

Сложность
В неделе указан Hard. Есть обычный чарт (workshop-rush.json)
и Hard (workshop-rush-hard.json).

Заметки
- Спрайт Tails оригинальный, без дорисованных зрачков.
- Голос Boyfriend заменён на присланную дорожку.
- Голос Tails — оригинальный из мода.
- Чарт собран по голосовым дорожкам. Первые секции отданы Tails.
- Фон увеличен, чтобы меньше чёрных полос.

Ограничения
- У Tails в исходном атласе нет зрачков.
- Направления стрелок в чарте не выверены вручную.
- Голос Tails пока не заменён.

Кредиты
Sonic / Tails — SEGA.
Psych Engine — Shadow Mario и сообщество.
Сборка для личного использования.

------------------------------------------------------------
ENGLISH
------------------------------------------------------------

Song: Workshop Rush
Week: Tails Workshop
Opponent: Tails
Player: Boyfriend
GF: Sonic

Requirements
Psych Engine 1.0.4 (PC or a mobile build that loads a mods folder).

Install
1. Extract the archive.
2. Put the Tails-Funkin-Psych folder into the mods folder next to Psych Engine.
   Example: PsychEngine/mods/Tails-Funkin-Psych/
3. Launch the game. If the week does not show up, enable the mod in the Mods menu.
4. The song is in Story Mode (Tails Workshop) and Freeplay (Workshop Rush).

Difficulty
The week lists Hard. Charts exist for normal (workshop-rush.json)
and Hard (workshop-rush-hard.json).

Notes
- The Tails sprite is the original atlas, with no added pupils.
- Boyfriend's voice was replaced with the supplied stem.
- Tails' voice is the original mod stem.
- The chart was built from the vocal stems. Early sections go to Tails.
- The background is scaled up to reduce black bars.

Limits
- The source Tails atlas has no pupils.
- Arrow directions in the chart were not hand-tuned.
- Tails' voice has not been replaced yet.

Credits
Sonic / Tails — SEGA.
Psych Engine — Shadow Mario and contributors.
This build is for personal use.
