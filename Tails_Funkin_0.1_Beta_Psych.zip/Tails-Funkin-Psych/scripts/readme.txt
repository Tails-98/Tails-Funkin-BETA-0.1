Tails Funkin Psych mod - scripts folder.
