local focus = {
    {time = 0,   x = 250, y = 555},
    {time = 20000, x = 850, y = 555},
    {time = 40000, x = 250, y = 555},
    {time = 60000, x = 850, y = 555},
    {time = 80000, x = 250, y = 555},
    {time = 95000, x = 850, y = 555}
}

local current = 1

function onCreate()
    setProperty('cameraSpeed', 1)
end

function onUpdatePost()
    if current <= #focus and getSongPosition() >= focus[current].time then
        triggerEvent('Camera Follow Pos', tostring(focus[current].x), tostring(focus[current].y))
        current = current + 1
    end
end
